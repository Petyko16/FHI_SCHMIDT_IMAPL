export function calculateTotalPrice(days: number, pricePerDay: number): number {
    return days * pricePerDay;
}
