export class RentalOffice {
    constructor(
        public name: string,
        public address: string
    ) {}
}
